-- ============================================================
-- CONFLICT WATCH — Row Level Security (RLS) Policies
-- Execute APÓS o schema.sql no Supabase SQL Editor
-- ============================================================

-- Habilitar RLS em todas as tabelas
ALTER TABLE public.users               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.news_events         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tension_history     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alerts              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_analyses       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alert_deliveries    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stripe_events       ENABLE ROW LEVEL SECURITY;

-- ── USERS ────────────────────────────────────────────────────

-- Usuário vê apenas seu próprio perfil
CREATE POLICY "users_select_own" ON public.users
  FOR SELECT USING (auth.uid() = id);

-- Usuário atualiza apenas seu próprio perfil
CREATE POLICY "users_update_own" ON public.users
  FOR UPDATE USING (auth.uid() = id);

-- Service role pode fazer tudo (backend)
CREATE POLICY "users_service_role_all" ON public.users
  FOR ALL USING (auth.role() = 'service_role');

-- ── NEWS_EVENTS ──────────────────────────────────────────────

-- Usuários FREE: últimas 24h apenas
CREATE POLICY "news_events_free_select" ON public.news_events
  FOR SELECT USING (
    auth.uid() IS NOT NULL AND (
      -- PRO vê tudo
      EXISTS (
        SELECT 1 FROM public.users 
        WHERE id = auth.uid() AND plan = 'pro'
      )
      OR
      -- FREE vê últimas 24h
      published_at > NOW() - INTERVAL '24 hours'
    )
  );

-- Usuários não logados: últimas 6h apenas (preview)
CREATE POLICY "news_events_anon_select" ON public.news_events
  FOR SELECT USING (
    auth.uid() IS NULL AND 
    published_at > NOW() - INTERVAL '6 hours' AND
    is_critical = false
  );

-- Service role: acesso total
CREATE POLICY "news_events_service_role" ON public.news_events
  FOR ALL USING (auth.role() = 'service_role');

-- ── TENSION_HISTORY ──────────────────────────────────────────

-- FREE: últimas 24h
-- PRO: últimos 90 dias
CREATE POLICY "tension_history_select" ON public.tension_history
  FOR SELECT USING (
    auth.uid() IS NOT NULL AND (
      EXISTS (
        SELECT 1 FROM public.users
        WHERE id = auth.uid() AND plan = 'pro'
      )
      OR
      created_at > NOW() - INTERVAL '24 hours'
    )
  );

-- Acesso público básico (últimas 6h, sem auth)
CREATE POLICY "tension_history_anon" ON public.tension_history
  FOR SELECT USING (
    auth.uid() IS NULL AND
    created_at > NOW() - INTERVAL '6 hours'
  );

CREATE POLICY "tension_history_service_role" ON public.tension_history
  FOR ALL USING (auth.role() = 'service_role');

-- ── ALERTS ───────────────────────────────────────────────────

-- Apenas usuários PRO veem alertas críticos
CREATE POLICY "alerts_pro_only" ON public.alerts
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE id = auth.uid() AND plan = 'pro'
    )
  );

CREATE POLICY "alerts_service_role" ON public.alerts
  FOR ALL USING (auth.role() = 'service_role');

-- ── USER_ANALYSES ────────────────────────────────────────────

-- Usuário vê apenas suas análises
CREATE POLICY "user_analyses_own" ON public.user_analyses
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "user_analyses_insert_own" ON public.user_analyses
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "user_analyses_service_role" ON public.user_analyses
  FOR ALL USING (auth.role() = 'service_role');

-- ── ALERT_DELIVERIES ─────────────────────────────────────────

CREATE POLICY "alert_deliveries_own" ON public.alert_deliveries
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "alert_deliveries_service_role" ON public.alert_deliveries
  FOR ALL USING (auth.role() = 'service_role');

-- ── STRIPE_EVENTS ────────────────────────────────────────────

-- Apenas service role acessa (nunca exposto ao frontend)
CREATE POLICY "stripe_events_service_role" ON public.stripe_events
  FOR ALL USING (auth.role() = 'service_role');

-- ══════════════════════════════════════════════════════════════
-- REALTIME — Habilitar para tabelas necessárias
-- ══════════════════════════════════════════════════════════════

-- Execute no Supabase: Database > Replication > Tables
-- OU via SQL:
ALTER PUBLICATION supabase_realtime ADD TABLE public.news_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.tension_history;
ALTER PUBLICATION supabase_realtime ADD TABLE public.alerts;
