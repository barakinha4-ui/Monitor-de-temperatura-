# 🏗️ Arquitetura — ConflictWatch SaaS

## Diagrama de Fluxo

```
┌─────────────────────────────────────────────────────────────────┐
│                        USUÁRIO FINAL                             │
└───────────────────────────┬─────────────────────────────────────┘
                            │ HTTPS
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                      VERCEL CDN                                  │
│              Frontend estático (HTML/CSS/JS)                     │
│  /index.html  /login.html  /pricing.html  /auth/callback.html   │
└───────────────────────────┬─────────────────────────────────────┘
                            │ REST API + Bearer Token
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                   RENDER — Node.js API                           │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ /api/auth    │  │ /api/analysis│  │ /api/stripe/webhook  │  │
│  │ /api/events  │  │ /api/tension │  │ /api/export          │  │
│  │ /api/alerts  │  │              │  │                       │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                  │                     │               │
│  ┌──────▼──────────────────▼─────────────────────▼───────────┐  │
│  │              Middleware Layer                               │  │
│  │  Auth (JWT) │ Plan Gate │ Rate Limit │ Logger │ Sanitize   │  │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                  Cron Job (5 min)                            │ │
│  │  NewsAPI/GNews → Claude AI → Supabase → Alert Check        │ │
│  └─────────────────────────────────────────────────────────────┘ │
└───────┬───────────┬──────────────────────┬───────────────────────┘
        │           │                      │
        ▼           ▼                      ▼
┌──────────┐  ┌──────────────┐  ┌──────────────────┐
│ Supabase │  │  Anthropic   │  │     Stripe       │
│ Postgres │  │  Claude API  │  │  Payments API    │
│ Auth     │  │              │  │  Webhooks        │
│ Realtime │  │              │  │                  │
└──────────┘  └──────────────┘  └──────────────────┘
```

---

## Fluxo de Autenticação

```
Frontend                    Backend                  Supabase Auth
    │                          │                          │
    │─── POST /auth/login ────►│                          │
    │                          │──── signInWithPassword ─►│
    │                          │◄─── JWT tokens ──────────│
    │◄── access_token ─────────│                          │
    │                          │                          │
    │ (guarda token localmente) │                          │
    │                          │                          │
    │─── GET /api/events ─────►│                          │
    │    Bearer: <token>        │                          │
    │                          │──── getUser(token) ─────►│
    │                          │◄─── user object ─────────│
    │                          │──── getUserById(id) ─────► Postgres
    │                          │◄─── profile + plan ───────│
    │◄── events (filtered) ────│                          │
```

---

## Fluxo de Pagamento Stripe

```
Frontend          Backend           Stripe          Supabase
    │                 │                │                │
    │── /checkout ───►│                │                │
    │                 │── create session ─────────────►│
    │                 │◄── checkout URL ────────────────│
    │◄── URL ─────────│                │                │
    │                 │                │                │
    │── (redireciona para Stripe) ────►│                │
    │                 │                │                │
    │◄── (redireciona após pagamento) ─│                │
    │                 │                │                │
    │                 │◄── webhook: checkout.session.completed
    │                 │── valida sig   │                │
    │                 │── updateUser ─────────────────►│
    │                 │   plan='pro'   │                │
    │                 │                │                │
    │ (próximo request: plan='pro' ────────────────────►│)
```

---

## Fluxo do Cron Job (cada 5 min)

```
node-cron
    │
    ├─► fetchLatestNews()
    │       NewsAPI.org / GNews.io
    │       ↓ ~20-50 artigos/ciclo
    │
    ├─► deduplicação por URL (Supabase)
    │
    ├─► Para cada artigo novo:
    │       │
    │       ├─► classifyNewsEvent(title, description)
    │       │       Claude API → { category, impact_score, is_critical, keywords }
    │       │
    │       ├─► translateNewsTitle(title)
    │       │       Claude API → { pt, es, ar, fa }
    │       │
    │       ├─► calculateTensionDelta(category, score, title)
    │       │       Algoritmo proprietário → delta ±N
    │       │
    │       └─► INSERT INTO news_events
    │
    ├─► applyTensionDelta(current, totalDelta)
    │       INSERT INTO tension_history
    │
    └─► Para eventos críticos (score >= 8):
            │
            ├─► INSERT INTO alerts
            │
            ├─► Supabase Realtime broadcast
            │       └─► Usuários PRO recebem notificação instantânea
            │
            └─► Telegram webhook (se configurado)
```

---

## Sistema de Rate Limiting

```
Camada 1: IP-based (express-rate-limit)
├── Global:     200 req / 15 min / IP
├── Auth:       20 req  / 15 min / IP
├── Analysis:   10 req  / 1 min  / IP ou userId
└── Export:     10 req  / 1 hora / userId

Camada 2: Business logic (PostgreSQL)
├── FREE: 5 análises IA / 24 horas / usuário
└── PRO: ilimitado

Camada 3: Supabase RLS
└── Filtra dados por plano automaticamente
```

---

## Segurança — Defesa em Profundidade

```
1. CORS             → Apenas origens whitelist
2. Helmet.js        → HTTP security headers
3. Rate Limit       → Anti-DDoS e brute force
4. Input Sanitize   → XSS, injection prevention
5. JWT Validation   → Supabase tokens verificados
6. RLS Policies     → Banco filtra por usuário/plano
7. Service Role     → API key privilegiada só no backend
8. Webhook Sig      → Stripe signature validation
9. Raw Body         → Preservado apenas para Stripe
10. Logs Redacted   → Dados sensíveis nunca logados
```

---

## Escalabilidade

### Gargalos atuais (free tier)
- Render Free: dorme após 15min (latência no cold start)
- NewsAPI Free: 100 req/dia (suficiente para ~15 keywords)
- Anthropic: sem limite hard, mas custo por token

### Escalar para 1.000 usuários
- Render Starter ($7/mês): sem sleep, 512MB RAM
- Redis (Upstash free): rate limit distribuído
- NewsAPI Developer: 500 req/dia

### Escalar para 10.000+ usuários
- Render Pro ($25+/mês) ou Railway
- Supabase Pro ($25/mês): connection pooling, mais storage
- Múltiplas instâncias com load balancer
- Queue system (BullMQ) para processar notícias async
- CDN para assets estáticos (já via Vercel)
