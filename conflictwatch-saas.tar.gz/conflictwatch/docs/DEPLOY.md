# 🚀 Guia de Deploy — ConflictWatch

## Visão Geral

```
Frontend: Vercel (gratuito)
Backend:  Render (gratuito para começar)
Banco:    Supabase (gratuito até 500MB)
Pagamento: Stripe (2.9% + R$0.30 por transação)
```

---

## 1️⃣ Supabase — Banco de Dados e Auth

### 1.1 Criar projeto
1. Acesse https://supabase.com → New Project
2. Escolha região mais próxima (ex: South America - São Paulo)
3. Anote as credenciais

### 1.2 Executar schema
1. Supabase Dashboard → SQL Editor → New Query
2. Cole o conteúdo de `supabase/schema.sql` → Run
3. Cole o conteúdo de `supabase/rls_policies.sql` → Run

### 1.3 Configurar Auth
1. Authentication → Providers → Email: habilitar
2. Authentication → Providers → Google:
   - Criar projeto no Google Cloud Console
   - Habilitar Google+ API
   - Criar OAuth 2.0 credentials
   - Adicionar `https://SEU_PROJETO.supabase.co/auth/v1/callback` como redirect URI
   - Colar Client ID e Secret no Supabase

### 1.4 Configurar Realtime
1. Database → Replication
2. Habilitar Realtime para: `news_events`, `tension_history`, `alerts`

### 1.5 Anotar credenciais
- Project URL: `https://xxxx.supabase.co`
- anon public key
- service_role secret key (NUNCA expor ao frontend)

---

## 2️⃣ Stripe — Pagamentos

### 2.1 Criar conta e produto
1. https://stripe.com → criar conta
2. Dashboard → Products → Add Product
   - Nome: "ConflictWatch PRO"
   - Price: R$49,00 / month (recurring)
   - Anotar `price_xxx` ID

### 2.2 Webhook
1. Developers → Webhooks → Add endpoint
   - URL: `https://sua-api.render.com/api/stripe/webhook`
   - Events: selecionar:
     - `checkout.session.completed`
     - `invoice.paid`
     - `invoice.payment_failed`
     - `customer.subscription.deleted`
     - `customer.subscription.updated`
2. Anotar o Webhook Signing Secret (`whsec_xxx`)

### 2.3 Testar localmente
```bash
# Instalar Stripe CLI
brew install stripe/stripe-cli/stripe

# Login
stripe login

# Forward webhook para local
stripe listen --forward-to localhost:3001/api/stripe/webhook

# Testar checkout
stripe trigger checkout.session.completed
```

---

## 3️⃣ NewsAPI e GNews

### NewsAPI (recomendado)
1. https://newsapi.org/register → criar conta gratuita
2. Anotar API Key (100 req/dia no plano gratuito)
3. Para produção: Developer plan ($449/mês) ou Business ($999/mês)

### GNews (backup)
1. https://gnews.io → criar conta
2. Anotar API Key

---

## 4️⃣ Backend — Deploy no Render

### 4.1 Preparar repositório
```bash
# Certifique-se que o .env NÃO está no git
echo ".env" >> .gitignore
git add .
git commit -m "Initial SaaS setup"
git push origin main
```

### 4.2 Criar Web Service no Render
1. https://render.com → New → Web Service
2. Conectar repositório GitHub
3. Configurações:
   - **Root Directory**: `backend`
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free (512MB RAM, vai dormir após inatividade)
   
4. Environment Variables (adicionar todas do `.env.example`):
   ```
   NODE_ENV=production
   PORT=10000
   APP_URL=https://conflictwatch.vercel.app
   SUPABASE_URL=https://xxx.supabase.co
   SUPABASE_ANON_KEY=eyJ...
   SUPABASE_SERVICE_ROLE_KEY=eyJ...
   JWT_SECRET=<gere com: openssl rand -base64 64>
   ANTHROPIC_API_KEY=sk-ant-...
   STRIPE_SECRET_KEY=sk_live_...
   STRIPE_PUBLISHABLE_KEY=pk_live_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   STRIPE_PRO_PRICE_ID=price_...
   NEWS_API_KEY=...
   GNEWS_API_KEY=...
   ALLOWED_ORIGINS=https://conflictwatch.vercel.app
   ```

5. Deploy → aguardar build
6. Anotar URL: `https://conflictwatch-api.onrender.com`

**Nota sobre Render Free**: O serviço dorme após 15min de inatividade.
Para produção real, use o plano pago ($7/mês) ou migre para Railway/Fly.io.

---

## 5️⃣ Frontend — Deploy no Vercel

### 5.1 Atualizar configurações
Editar `frontend/public/login.html`, `pricing.html` e `index.html`:
```javascript
window.CW_CONFIG = {
  supabaseUrl:  'https://SEU_PROJETO.supabase.co',
  supabaseAnon: 'SUA_ANON_KEY_AQUI',
  apiUrl:       'https://conflictwatch-api.onrender.com',
  appUrl:       'https://conflictwatch.vercel.app',
};
```

### 5.2 Deploy
1. https://vercel.com → Import Project
2. Selecionar repositório
3. **Root Directory**: deixar em branco (usa `vercel.json`)
4. Deploy

### 5.3 Domínio personalizado (opcional)
1. Vercel → Domains → Add
2. Configurar DNS

---

## 6️⃣ Verificação Final

```bash
# Health check da API
curl https://conflictwatch-api.onrender.com/health

# Deve retornar:
# {"status":"ok","service":"conflictwatch-api",...}

# Testar endpoint de tensão
curl https://conflictwatch-api.onrender.com/api/tension/current

# Verificar frontend
open https://conflictwatch.vercel.app
```

---

## 🔧 Manutenção

### Logs em produção
```bash
# Render: Dashboard → Logs (tempo real)
# Supabase: Dashboard → Logs → API logs
```

### Atualizar deploy
```bash
git push origin main
# Render e Vercel fazem auto-deploy
```

### Monitoramento de custos
- Supabase: monitorar storage e bandwidth
- NewsAPI: monitorar requests/dia (100 grátis)
- Anthropic: monitorar tokens usados
- Stripe: 2.9% + R$0.30 por transação

---

## 💡 Escalar para Produção

Quando crescer além do free tier:

1. **Render Starter** ($7/mês) → sem sleep, mais RAM
2. **Redis** (Upstash gratuito) → rate limiting distribuído
3. **Supabase Pro** ($25/mês) → mais storage, backups diários
4. **CDN** → Cloudflare grátis para static assets
5. **NewsAPI Developer** → 500 req/dia, sem restrição de domínio
