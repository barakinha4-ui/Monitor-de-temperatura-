# 💳 Configuração Stripe — Passo a Passo

## 1. Criar Conta e Produto

```bash
# Instalar Stripe CLI (necessário para testes)
# macOS:
brew install stripe/stripe-cli/stripe

# Linux:
curl -s https://packages.stripe.dev/api/security/keypair/stripe-cli-gpg/public | gpg --dearmor | sudo tee /usr/share/keyrings/stripe.gpg
echo "deb [signed-by=/usr/share/keyrings/stripe.gpg] https://packages.stripe.dev/stripe-cli-debian-local stable main" | sudo tee -a /etc/apt/sources.list.d/stripe.list
sudo apt update && sudo apt install stripe
```

## 2. Criar Produto PRO

Via Dashboard (https://dashboard.stripe.com/products):

```
Nome:        ConflictWatch PRO — Intelligence Plan
Descrição:   Análises IA ilimitadas, alertas críticos em tempo real, histórico 90 dias
Preço:       R$ 49,00 / mês (recorrente)
Moeda:       BRL
Cobrança:    Mensal
```

Ou via CLI:
```bash
stripe products create \
  --name "ConflictWatch PRO" \
  --description "Geopolitical intelligence premium plan"

stripe prices create \
  --product prod_XXXX \
  --unit-amount 4900 \
  --currency brl \
  --recurring[interval] month
```

## 3. Configurar Customer Portal

https://dashboard.stripe.com/settings/billing/portal

Habilitar:
- ✅ Cancel subscriptions
- ✅ Update payment methods
- ✅ View invoices
- ✅ Switch plans (se tiver múltiplos)

## 4. Configurar Webhook

https://dashboard.stripe.com/webhooks → Add endpoint

```
Endpoint URL: https://sua-api.render.com/api/stripe/webhook

Events to listen:
✅ checkout.session.completed
✅ invoice.paid
✅ invoice.payment_failed
✅ customer.subscription.deleted
✅ customer.subscription.updated
```

Copiar o **Webhook Signing Secret** (whsec_xxx) para o `.env`.

## 5. Testar Localmente

```bash
# Terminal 1: Backend rodando
cd backend && npm run dev

# Terminal 2: Stripe forwarding
stripe login
stripe listen --forward-to localhost:3001/api/stripe/webhook

# Terminal 3: Disparar eventos de teste
stripe trigger checkout.session.completed
stripe trigger invoice.paid
stripe trigger customer.subscription.deleted

# Testar com cartão de crédito de teste:
# Número: 4242 4242 4242 4242
# Data:   qualquer data futura
# CVC:    qualquer 3 dígitos
# CEP:    qualquer
```

## 6. Variáveis de Ambiente

```env
# .env (desenvolvimento)
STRIPE_SECRET_KEY=sk_test_...       ← chave de TESTE
STRIPE_PUBLISHABLE_KEY=pk_test_...  ← chave de TESTE
STRIPE_WEBHOOK_SECRET=whsec_...     ← do stripe listen local
STRIPE_PRO_PRICE_ID=price_...

# Produção (Render)
STRIPE_SECRET_KEY=sk_live_...       ← chave LIVE
STRIPE_PUBLISHABLE_KEY=pk_live_...  ← chave LIVE
STRIPE_WEBHOOK_SECRET=whsec_...     ← do webhook do dashboard
```

## 7. Checklist antes de ir ao ar

- [ ] Completar informações de negócio no Stripe (nome, endereço, etc.)
- [ ] Adicionar método de recebimento (conta bancária brasileira)
- [ ] Habilitar pagamentos PIX (opcional, mas recomendado para BR)
- [ ] Configurar email de confirmação personalizado
- [ ] Testar fluxo completo em modo TEST
- [ ] Trocar chaves TEST → LIVE
- [ ] Verificar webhook LIVE

## 8. Impostos (se aplicável)

Para SaaS no Brasil:
- ISS: 2-5% (município)
- Verificar necessidade de emissão de Nota Fiscal de Serviços
- Stripe Tax pode automatizar alguns países (Brasil em fase beta)
